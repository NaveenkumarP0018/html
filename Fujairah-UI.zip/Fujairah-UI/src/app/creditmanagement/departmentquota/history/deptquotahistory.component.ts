import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deptquotahistory',
  templateUrl: './deptquotahistory.component.html',
  styleUrls: ['./deptquotahistory.component.scss']
})
export class DeptquotahistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
