import { Routes } from '@angular/router';
import { SmartdirectoryComponent } from './smartmanage/smartdirectory.component';

export const SmartDirectoryRoutes: Routes = [{
    path: '',
    component: SmartdirectoryComponent
}];
