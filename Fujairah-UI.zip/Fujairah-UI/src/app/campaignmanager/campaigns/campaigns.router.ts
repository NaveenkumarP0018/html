import { Routes } from '@angular/router';
import { SmscampaignComponent } from './manage/smscampaign.component';

export const CampaignRoutes: Routes = [{

    path: '',
      component: SmscampaignComponent
}];
