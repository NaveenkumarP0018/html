import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staticdashboard',
  templateUrl: './staticdashboard.component.html',
  styleUrls: ['./staticdashboard.component.scss']
})
export class StaticdashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
