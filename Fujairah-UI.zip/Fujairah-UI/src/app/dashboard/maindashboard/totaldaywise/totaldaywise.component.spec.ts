import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TotaldaywiseComponent } from './totaldaywise.component';

describe('TotaldaywiseComponent', () => {
  let component: TotaldaywiseComponent;
  let fixture: ComponentFixture<TotaldaywiseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TotaldaywiseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TotaldaywiseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
