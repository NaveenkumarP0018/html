import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ICampSubmit, IDaywiseData, BarChart } from '../_model/maindashboard.model';
import * as _ from 'lodash';
import { MainDashBoardService } from '../_service/maindashboard.service';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Observable } from 'rxjs';
import { AlertMessageService, ActionType } from '../../../_services/AlertMessageService';
import { AppConfig } from '../../../_helpers/app.config';
import 'chartjs-plugin-labels';
@Component({
  selector: 'app-totaldaywise',
  templateUrl: './totaldaywise.component.html',
  styleUrls: ['./totaldaywise.component.scss']
})
export class TotaldaywiseComponent implements OnInit {
  globalbarChartOptions: any = {
    responsive: true,
    legend: {
      onClick: null,
      display: true,
      position: 'bottom',
      labels: {
        usePointStyle: true,
      }
    },
    plugins: {
      labels: false,
      render: 'text'
    }
  };
  barChartHorizontalOptions: any = Object.assign({
    scaleShowVerticalLines: false,
    scales: {
      xAxes: [{
        gridLines: {
          color: 'rgba(0,0,0,0.02)',
          zeroLineColor: 'rgba(0,0,0,0.02)'
        },
        ticks: {
          beginAtZero: true,
          suggestedMax: 9,
          autoSkip: false
        }
      }],
      yAxes: [{
        gridLines: {
          color: 'rgba(0,0,0,0.02)',
          zeroLineColor: 'rgba(0,0,0,0.02)'
        }
      }]
    }
  }, this.globalbarChartOptions);
  dayWiseChartColors: Array<any> = [
    {//Email 
      backgroundColor: 'rgb(79, 129, 189)',
      borderColor: 'rgb(79, 129, 189)',
      pointBorderColor: 'rgb(79, 129, 189)',
      pointHoverBackgroundColor: 'rgb(79, 129, 189)',
      pointHoverBorderColor: 'rgb(79, 129, 189)',
      borderWidth: 1,
      pointRadius: 1,
      pointHoverRadius: 3,
      pointHoverBorderWidth: 0
    },
    { //SMS
      backgroundColor: 'rgb(192, 80, 77)',
      borderColor: 'rgb(192, 80, 77)',
      pointBorderColor: 'rgb(192, 80, 77)',
      pointHoverBackgroundColor: 'rgb(192, 80, 77)',
      pointHoverBorderColor: 'rgb(192, 80, 77)',
      borderWidth: 1,
      pointRadius: 1,
      pointHoverRadius: 3,
      pointHoverBorderWidth: 0
    }]
    dashboardInterval:number;
  @Input() requestData: ICampSubmit;
  @Output() TotaDaywiseData= new EventEmitter<BarChart[]>(); 
  dRequestData: ICampSubmit;
  myTimeout: any;
  todayLoading: boolean = false;
  dayWiseChartLabels: string[] = [];
  dayWiseData: BarChart[] = [];
  responseData: IDaywiseData[] = [];
  constructor(private dashBoardService: MainDashBoardService, private router: Router, private translate: TranslateService, private alertMessage: AlertMessageService,private appconfig:AppConfig) {
    this.dashboardInterval=this.appconfig.getdashboardInterval();
  }

  ngOnInit() {

    if (this.requestData) {
      this.dRequestData = this.requestData;
    }
    if (!this.todayLoading) {
      this.todayLoading = true;
      this.getDayWiseCount();
    }
    this.myTimeout = Observable.interval(60000).subscribe(data => {
      console.log("entered to observable");
      if (!this.todayLoading) {
        this.getDayWiseCount();
      }
    });
    console.log("requestData==>", this.dRequestData);
  }
  getDayWiseCount() {
    console.log("campsubmitData==>", JSON.stringify(this.dRequestData));
    this.dashBoardService.getDayWiseCount(this.dRequestData).subscribe((response: IDaywiseData[]) => {
      console.log("daywiseCount response==>", response);
      if (response.length > 0) {
        if (!_.isEqual(this.responseData, response)) {
          
          let pushable: boolean = true;
          this.dayWiseData = [];
          this.dayWiseChartLabels = [];
          this.responseData = response
          setTimeout(() => {
            this.responseData.forEach(camp => {
              if (pushable) {
                this.dayWiseData.push({ label: '', data: [] });
                pushable = false
              }
              this.dayWiseChartLabels.push(camp.date);
              let i = 0;
              Object.keys(camp).forEach(x => {
                if (typeof camp['' + x] === "number" && !x.toLowerCase().includes("id")) {
                  let lableName=this.translate.instant('DashBoardModule.totalDayWise.'+x);
                  let filterindex = this.dayWiseData.findIndex(y => y.label.includes(x) || y.label.includes(lableName));
                  if (filterindex == -1)
                  {
                    this.dayWiseData[i].label = lableName =='DashBoardModule.totalDayWise.'+x ? x:lableName;
                  }
                  if (this.dayWiseData[i].label == '' && this.dayWiseData[i].label == undefined) {
                    this.dayWiseData.slice(i, 1);
                  }
                  if (filterindex != -1 || !pushable) {
                    this.dayWiseData[i].data.push(camp['' + x]);
                  }
                  i++;
                }
              });
            });
          }, 0);
          this.TotaDaywiseData.emit(this.dayWiseData);
          console.log("dayWiseData==>", this.responseData, this.dayWiseData);
        }
      }
      else {
        this.responseData = [];
        this.dayWiseData = []
        this.dayWiseChartLabels = [];
        this.TotaDaywiseData.emit(this.dayWiseData);
      }
      this.todayLoading = false;

    }, error => {
      this.responseData = [];
      this.dayWiseData = []
      this.dayWiseChartLabels = []
      let message = error.error.messages as string
      let errorMessage = error.status == 404 ? this.translate.instant('ActionNames.errorResponse') : message ? message : error.message;
      console.error("E-getDayWiseCount==>", JSON.stringify(error));
      this.showAlert(errorMessage, ActionType.ERROR, error.status);
      this.todayLoading = false;
    });
  }
  showAlert(error: any, action: ActionType, status: number = 0) {
    if (status == 401)
      this.router.navigate(['401']);
    else setTimeout(() => this.alertMessage.showAlert(error, action));
  }
  ngOnDestroy() {
    console.log("myTimeout==>", this.myTimeout);
    if (this.myTimeout)
      this.myTimeout.unsubscribe();
  }
  ngAfterViewChecked() {
    if (!_.isEqual(this.dRequestData, this.requestData)) {
      this.dRequestData = this.requestData
      if (!this.todayLoading) {
        this.todayLoading = true;
        this.getDayWiseCount();
      }
      console.log("requestData ", this.requestData);
    }
    // console.log("requestData view checked==>", this.requestData);
  }

}
