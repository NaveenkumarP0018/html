import { Routes } from '@angular/router';
import { MaindashboardComponent } from './manage/maindashboard.component'

export const MainDashboardRoutes: Routes = [
   { 
          path: '',
          children: 
          [
              {
                path: '',
                component: MaindashboardComponent
             }
          ]
    } 
];
