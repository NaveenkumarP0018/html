import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import * as _ from 'lodash';
import { MainDashBoardService } from '../_service/maindashboard.service';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Observable } from 'rxjs';
import { AlertMessageService, ActionType } from '../../../_services/AlertMessageService';
import { BarChart, ICampSubmit, IServiceData } from '../_model/maindashboard.model';
import { AppConfig } from '../../../_helpers/app.config';
import 'chartjs-plugin-labels';
@Component({
  selector: 'app-service-chart',
  templateUrl: './service-chart.component.html',
  styleUrls: ['./service-chart.component.scss']
})
export class ServiceChartComponent implements OnInit {
  @Input() expand:boolean;
  expand2:boolean = false;
  graphWidth:any='335px';
  globalbarChartOptions: any = {
    responsive: true,
    legend: {
      onClick: null,
      display: true,
      position: 'bottom',
      labels: {
        usePointStyle: true,
      }
    },
    plugins: {
      labels: false,
      render: 'text'
    }
  };
  barChartHorizontalOptions: any = Object.assign({
    scaleShowVerticalLines: false,
    scales: {
      xAxes: [{
        gridLines: {
          color: 'rgba(0,0,0,0.02)',
          zeroLineColor: 'rgba(0,0,0,0.02)'
        },
        ticks: {
          beginAtZero: true,
          suggestedMax: 9,
          autoSkip: false,
          callback: function (value) {
            if (value.length > 6) {
              return value.substr(0, 6) + '...';
            }
            else {
              return value
            }
          },
        }
      }],
      yAxes: [{
        gridLines: {
          color: 'rgba(0,0,0,0.02)',
          zeroLineColor: 'rgba(0,0,0,0.02)'
        },
        ticks: {
          beginAtZero: true
        }
      }]
    },
    tooltips: {
      enabled: true,
      mode: 'nearest',
      callbacks: {
        title: function (tooltipItems, data) {
          var idx = tooltipItems[0].index;
          return data.labels[idx];
        }
      }
    }
  }, this.globalbarChartOptions);
  serviceChartColors: Array<any> = [
    { //Base Uploaded
      backgroundColor: 'rgb(128, 100, 162)',
      borderColor: 'rgb(128, 100, 162)',
      pointBorderColor: 'rgb(128, 100, 162)',
      pointHoverBackgroundColor: 'rgb(128, 100, 162)',
      pointHoverBorderColor: 'rgb(128, 100, 162)',
      borderWidth: 1,
      pointRadius: 1,
      pointHoverRadius: 3,
      pointHoverBorderWidth: 0
    }, { // Sent
      backgroundColor: 'rgb(84, 156, 255)',
      borderColor: 'rgb(84, 156, 255)',
      pointBorderColor: 'rgb(84, 156, 255)',
      pointHoverBackgroundColor: 'rgb(84, 156, 255)',
      pointHoverBorderColor: 'rgb(84, 156, 255)',
      borderWidth: 1,
      pointRadius: 1,
      pointHoverRadius: 3,
      pointHoverBorderWidth: 0
    }, { // Delivered
      backgroundColor: 'rgb(155, 187, 89)',
      borderColor: 'rgb(155, 187, 89)',
      pointBorderColor: 'rgb(155, 187, 89)',
      pointHoverBackgroundColor: 'rgb(155, 187, 89)',
      pointHoverBorderColor: 'rgb(155, 187, 89)',
      borderWidth: 1,
      pointRadius: 1,
      pointHoverRadius: 3,
      pointHoverBorderWidth: 0
    }, { // Un-Delivered
      backgroundColor: 'rgb(243, 192, 0)',
      borderColor: 'rgb(243, 192, 0)',
      pointBorderColor: 'rgb(243, 192, 0)',
      pointHoverBackgroundColor: 'rgb(243, 192, 0)',
      pointHoverBorderColor: 'rgb(243, 192, 0)',
      borderWidth: 1,
      pointRadius: 1,
      pointHoverRadius: 3,
      pointHoverBorderWidth: 0
    }, { // Expired
      backgroundColor: 'rgb(155, 155, 155)',
      borderColor: 'rgb(155, 155, 155)',
      pointBorderColor: 'rgb(155, 155, 155)',
      pointHoverBackgroundColor: 'rgb(155, 155, 155)',
      pointHoverBorderColor: 'rgb(155, 155, 155)',
      borderWidth: 1,
      pointRadius: 1,
      pointHoverRadius: 3,
      pointHoverBorderWidth: 0
    }, { // Rejected
      backgroundColor: 'rgb(232, 7, 7)',
      borderColor: 'rgb(232, 7, 7)',
      pointBorderColor: 'rgb(232, 7, 7)',
      pointHoverBackgroundColor: 'rgb(232, 7, 7)',
      pointHoverBorderColor: 'rgb(232, 7, 7)',
      borderWidth: 1,
      pointRadius: 1,
      pointHoverRadius: 3,
      pointHoverBorderWidth: 0
    }, { // Failed
      backgroundColor: 'rgb(255, 150, 46)',
      borderColor: 'rgb(255, 150, 46)',
      pointBorderColor: 'rgb(255, 150, 46)',
      pointHoverBackgroundColor: 'rgb(255, 150, 46)',
      pointHoverBorderColor: 'rgb(255, 150, 46)',
      borderWidth: 1,
      pointRadius: 1,
      pointHoverRadius: 3,
      pointHoverBorderWidth: 0
    }];
  dashboardInterval: number;
  @Input() requestData: ICampSubmit;
  @Output() prioritywiseData = new EventEmitter<BarChart[]>()
  dRequestData: ICampSubmit;
  myTimeout: any;
  serviceWiseData: BarChart[] = [];
  serviceChartLabels: string[] = [];
  serviceLoading: boolean = false;
  responseData: IServiceData[] = [];
  constructor(private dashBoardService: MainDashBoardService, private router: Router,
    private translate: TranslateService, private alertMessage: AlertMessageService, private appconfig: AppConfig) {
    this.dashboardInterval = this.appconfig.getdashboardInterval();
  }

  ngOnInit() {
    this.expand2 = this.expand;
    if (this.requestData) {
      this.dRequestData = this.requestData;
    }
    if (!this.serviceLoading) {
      this.serviceLoading = true;
      this.getServicewiseCount();
    }
    this.myTimeout = Observable.interval(60000).subscribe(data => {
      console.log("entered to observable");
      if (!this.serviceLoading) {
        this.getServicewiseCount();
      }
    });
    console.log("requestData==>", this.dRequestData);
  }
  getServicewiseCount() {
    this.dashBoardService.getServicewiseCount(this.dRequestData).subscribe((result: IServiceData[]) => {
      console.log("getServicewiseCountresult=>", result);
      if (result.length > 0) {
        if (!_.isEqual(this.responseData, result)) {
          let pushable: boolean = true;
          this.serviceWiseData = [];
          this.serviceChartLabels = [];
          if(!this.expand2) {
            this.graphWidth=result.length>5?(result.length*67)+'px':'335px';
          }
          else{
           this.graphWidth=result.length>10?(result.length*10)+'%':'100%';
          }
          this.responseData = result;
          setTimeout(() => {
            this.responseData.forEach(service => {
              if (pushable) {
                this.serviceWiseData.push({ label: '', data: [] });
                pushable = false
              }
              this.serviceChartLabels.push(service.serviceCode);
              let i = 0;
              Object.keys(service).forEach(x => {
                if (typeof service['' + x] === "number" && !x.toLowerCase().includes("id")) {
                  let labelName = this.translate.instant('DashBoardModule.serviceChart.' + x);
                  let filterindex = this.serviceWiseData.findIndex(y => y.label.includes(x) || y.label.includes(labelName));
                  if (filterindex == -1) {
                    this.serviceWiseData.push({ label: labelName == 'DashBoardModule.serviceChart.' + x ? x : labelName, data: [service['' + x]] });
                  }
                  if (this.serviceWiseData[i].label == '' || this.serviceWiseData[i].label == undefined) {
                    console.log("undefined or empty", this.serviceWiseData);
                    this.serviceWiseData.splice(i, 1);
                  }
                  if (filterindex != -1 || pushable) {
                    this.serviceWiseData[i].data.push(service['' + x]);
                  }
                  i++;
                }
              });
            });
          }, 0);
          this.prioritywiseData.emit(this.serviceWiseData);
          console.log("serviceWiseData==>", this.responseData, this.serviceWiseData, this.serviceChartLabels)
        }
      } else {
        this.responseData = [];
        this.serviceWiseData = [];
        this.serviceChartLabels = [];
        this.prioritywiseData.emit(this.serviceWiseData);
      }
      this.serviceLoading = false;
    },
      error => {
        this.responseData = [];
        this.serviceWiseData = []
        this.serviceChartLabels = []
        this.serviceLoading = false;
        let message = error.error.messages as string
        let errorMessage = error.status == 404 ? this.translate.instant('ActionNames.errorResponse') : message ? message : error.message;
        console.error("E-getServicewiseCount==>", JSON.stringify(error));
        this.showAlert(errorMessage, ActionType.ERROR, error.status);
      });
  }
  showAlert(error: any, action: ActionType, status: number = 0) {
    if (status == 401)
      this.router.navigate(['401']);
    else setTimeout(() => this.alertMessage.showAlert(error, action));
  }
  ngOnDestroy() {
    console.log("myTimeout==>", this.myTimeout);
    if (this.myTimeout)
      this.myTimeout.unsubscribe();
  }
  ngAfterViewChecked() {
    if (!_.isEqual(this.dRequestData, this.requestData)) {
      this.expand2 = this.expand;
      this.dRequestData = this.requestData
      if (!this.serviceLoading) {
        this.serviceLoading = true;
        this.getServicewiseCount();
      }
      console.log("requestData view checked==>", this.dRequestData);
    }
    else
    {
      if(this.expand2 != this.expand)
      {
        this.expand2 = this.expand;
        if(!this.expand2) {
          this.graphWidth=this.responseData.length>5?(this.responseData.length*67)+'px':'335px';
        }
        else{
         this.graphWidth=this.responseData.length>10?(this.responseData.length*10)+'%':'100%';
        }
      }
    }
  }
}
