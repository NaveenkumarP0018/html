import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ICampSubmit, IModuleData } from '../_model/maindashboard.model';
import * as _ from 'lodash';
import { MainDashBoardService } from '../_service/maindashboard.service';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Observable } from 'rxjs';
import { AlertMessageService, ActionType } from '../../../_services/AlertMessageService';
import { AppConfig } from '../../../_helpers/app.config';
import 'chartjs-plugin-labels';
@Component({
  selector: 'app-modulewise-chart',
  templateUrl: './modulewise-chart.component.html',
  styleUrls: ['./modulewise-chart.component.scss']
})
export class ModulewiseChartComponent implements OnInit {
  dashboardInterval:number;
  moduleWiseData: number[] = [];
  moduleChartLabels: string[] = [];
  myTimeout: any;
  moduleLoading: boolean = false;
  @Input() requestData: ICampSubmit;
  @Output() ModulewiseData = new EventEmitter<number[]>(); 
  dRequestData: ICampSubmit;
  globalpieChartOptions: any = {
    responsive: true,
    legend: {
      onClick: null,
      display: true,
      position: 'bottom',
      labels: {
        usePointStyle: true,
      }
    },
    plugins: {
      labels: false,
      render: 'text'
    }
  };
  moduleChartColors: any[] = [{
    backgroundColor: ['#4F81BD', '#C0504D', '#9BBB59', '#8064A2', '#FFA500', '#0000FF', '#FFFF33']
  }];
  responseData: IModuleData[] = [];
  constructor(private dashBoardService: MainDashBoardService, private router: Router, private translate: TranslateService, private alertMessage: AlertMessageService,private appconfig:AppConfig) {
    this.dashboardInterval=this.appconfig.getdashboardInterval();

  }
  ngOnInit() {
    if (this.requestData) {
      this.dRequestData = this.requestData;
    }
    if (!this.moduleLoading) {
      this.moduleLoading = true;
      this.getModuleWiseCount();
    }
    this.myTimeout = Observable.interval(this.dashboardInterval*60000).subscribe(() => {
      console.log("entered to observable");
      if (!this.moduleLoading) {
        this.getModuleWiseCount();
      }
    });
  }

  getModuleWiseCount() {
    console.log("this.campsubmitData piecomponent==>", this.dRequestData);
    this.dashBoardService.getModuleWiseCount(this.dRequestData).subscribe((response: IModuleData[]) => {
      console.log("moduleData response==>", response);
      if (response.length > 0) {
        if (!_.isEqual(this.responseData, response)) {
          this.moduleWiseData = [];
          this.moduleChartLabels = [];
          this.responseData = response;
          setTimeout(() => {
            let sumby=_.sumBy(this.responseData, 'count');
            let percentage1=100;
            let lastModuleName=this.responseData[this.responseData.length-1].moduleName;
            this.responseData.forEach((camp: IModuleData) => {
              let percentage=((camp.count * 100 / sumby).toFixed(1)+'').includes('.0')?(camp.count * 100 / sumby).toFixed(0):(camp.count * 100 / sumby).toFixed(1);
              percentage1=percentage1- +(camp.count * 100 / sumby).toFixed(1);
             
             if(lastModuleName==camp.moduleName)
             percentage=((+percentage+ +percentage1).toFixed(1)).includes('.0')?(+percentage+ +percentage1).toFixed(0):(+percentage+ +percentage1).toFixed(1);
             console.log("percentage=>",percentage1,percentage);
              let lableName=this.translate.instant('DashBoardModule.moduleWiseChart.'+camp.moduleName);
              this.moduleChartLabels.push((lableName =='DashBoardModule.moduleWiseChart.'+camp.moduleName ? camp.moduleName:lableName)+" ("+percentage + '%)' );
              this.moduleWiseData.push(camp.count);
            });
          }, 0);
          this.ModulewiseData.emit(this.moduleWiseData);
          console.log("moduleWiseData==>", this.responseData, this.moduleWiseData, this.moduleChartLabels);
        }
      }
      else {
        this.moduleWiseData = [];
        this.moduleChartLabels = [];
        this.responseData = [];
        this.ModulewiseData.emit(this.moduleWiseData);
      }
      this.moduleLoading = false;
    }, error => {
      this.moduleWiseData = [];
      this.moduleChartLabels = [];
      this.responseData = [];
      let message = error.error.messages as string
      let errorMessage = error.status == 404 ? this.translate.instant('ActionNames.errorResponse') : message ? message : error.message;
      console.error("E-getModuleWiseCount==>", JSON.stringify(error));
      this.showAlert(errorMessage, ActionType.ERROR, error.status);
      this.moduleLoading = false;
    });
  }

  ngAfterViewChecked() {
    if (!_.isEqual(this.dRequestData, this.requestData)) {
      this.dRequestData = this.requestData
      if (!this.moduleLoading) {
        this.moduleLoading = true;
        this.getModuleWiseCount();
      }
      console.log("requestData view checked==>", this.dRequestData);
    }
  }
  showAlert(error: any, action: ActionType, status: number = 0) {
    if (status == 401)
      this.router.navigate(['401']);
    else setTimeout(() => this.alertMessage.showAlert(error, action));
  }

  ngOnDestroy() {
    console.log("myTimeout==>", this.myTimeout);
    if (this.myTimeout)
      this.myTimeout.unsubscribe();
  }

}
