import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModulewiseChartComponent } from './modulewise-chart.component';

describe('ModulewiseChartComponent', () => {
  let component: ModulewiseChartComponent;
  let fixture: ComponentFixture<ModulewiseChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModulewiseChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModulewiseChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
