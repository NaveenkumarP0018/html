import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TotalactivityComponent } from './totalactivity.component';

describe('TotalactivityComponent', () => {
  let component: TotalactivityComponent;
  let fixture: ComponentFixture<TotalactivityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TotalactivityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TotalactivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
