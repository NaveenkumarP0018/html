import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ICampSubmit, ITotalCount } from '../_model/maindashboard.model';
import { MainDashBoardService } from '../_service/maindashboard.service';
import { Router } from '@angular/router';
import { AlertMessageService, ActionType } from '../../../_services/AlertMessageService';
import { TranslateService } from '@ngx-translate/core';
import { AppConfig } from '../../../_helpers/app.config';
import { Observable } from 'rxjs';
import * as _ from 'lodash';
import 'chartjs-plugin-labels';
@Component({
  selector: 'app-totalactivity',
  templateUrl: './totalactivity.component.html',
  styleUrls: ['./totalactivity.component.scss']
})
export class TotalactivityComponent implements OnInit {

  doughnutChartColors: any[] = [{
    backgroundColor: ['#4F81BD', '#C0504D', '#9BBB59', '#8064A2', '#FFA500', '#0000FF', '#FFFF33']
  }];
  globalChartOptions: any = {
    responsive: true,
    legend: {
      onClick: null,
      display: true,
      position: 'bottom',
      labels: {
        usePointStyle: true,
      }
    },
    plugins: {
      labels: false,
      render: 'text'
    }
  };
  @Input() requestData: ICampSubmit;
  @Output() TotalActivityData = new EventEmitter<number[]>();
  dRequestData: ICampSubmit;
  dashboardInterval:number=0;
  responseData:ITotalCount[]=[];
  totalActivtyLoading:boolean=false;
  myTimeout:any;
  totalActivityChartLabels:string[]=[];
  totalActivityData:number[]=[];
  constructor(private dashBoardService: MainDashBoardService, private router: Router, private translate: TranslateService, private alertMessage: AlertMessageService,private appconfig:AppConfig) {
    this.dashboardInterval=this.appconfig.getdashboardInterval();

  }

  ngOnInit() {
    if (this.requestData) {
      this.dRequestData = this.requestData;
    }
    if (!this.totalActivtyLoading) {
      this.totalActivtyLoading = true;
      this.getTotalActivityCount();
    }
    this.myTimeout = Observable.interval(this.dashboardInterval*60000).subscribe(() => {
      console.log("entered to observable");
      if (!this.totalActivtyLoading) {
        this.getTotalActivityCount();
      }
    });
  }
  getTotalActivityCount() {
    console.log("this.campsubmitData piecomponent==>", this.dRequestData);
    this.dashBoardService.getTotalCount(this.dRequestData).subscribe((response: ITotalCount[]) => {
      console.log("moduleData response==>", response);
      if (response.length > 0) {
        if (!_.isEqual(this.responseData, response)) {
          this.totalActivityData = [];
          this.totalActivityChartLabels = [];
          this.responseData = response;
          setTimeout(() => {
            let percentage1=100;
            let lastModuleIndex=this.responseData.length;
            this.responseData.forEach((camp: ITotalCount) => {
              Object.keys(camp).forEach(x=>{
                console.log("sumby",_.sumBy(this.responseData, x));
                lastModuleIndex--;
                let sumby=_.sumBy(this.responseData,  x);
                let percentage=((camp['' + x] * 100 / sumby).toFixed(1)+'').includes('.0')?(camp['' + x] * 100 / sumby).toFixed(0):(camp['' + x] * 100 / sumby).toFixed(1);
                percentage1=percentage1- +(camp['' + x] * 100 / sumby).toFixed(1);
             
                if(lastModuleIndex<=0)
                percentage=((+percentage+ +percentage1).toFixed(1)).includes('.0')?(+percentage+ +percentage1).toFixed(0):(+percentage+ +percentage1).toFixed(1);
                console.log("percentage=>",percentage1,percentage);
                let lableName=this.translate.instant('DashBoardModule.totalDayWise.'+x);
                this.totalActivityChartLabels.push(lableName =='DashBoardModule.totalDayWise.'+x ? x:lableName+" ("+percentage + '%)');
                this.totalActivityData.push(camp['' + x]);
              })
              
            });
          }, 0);
          this.TotalActivityData.emit(this.totalActivityData);
          console.log("totalActivityData==>", this.responseData, this.totalActivityData, this.totalActivityChartLabels);
        }
      }
      else {
        this.totalActivityData = [];
        this.totalActivityChartLabels = [];
        this.responseData = [];
        this.TotalActivityData.emit(this.totalActivityData);
      }
      this.totalActivtyLoading = false;
    }, error => {
      this.totalActivityData = [];
      this.totalActivityChartLabels = [];
      this.responseData = [];
      let message = error.error.messages as string
      let errorMessage = error.status == 404 ? this.translate.instant('ActionNames.errorResponse') : message ? message : error.message;
      console.error("E-getTotalActivityCount==>", JSON.stringify(error));
      this.showAlert(errorMessage, ActionType.ERROR, error.status);
      this.totalActivtyLoading = false;
    });
  }
  ngAfterViewChecked() {
    if (!_.isEqual(this.dRequestData, this.requestData)) {
      this.dRequestData = this.requestData
      if (!this.totalActivtyLoading) {
        this.totalActivtyLoading = true;
        this.getTotalActivityCount();
      }
      console.log("requestData view checked==>", this.dRequestData);
    }
  }
  showAlert(error: any, action: ActionType, status: number = 0) {
    if (status == 401)
      this.router.navigate(['401']);
    else setTimeout(() => this.alertMessage.showAlert(error, action));
  }

  ngOnDestroy() {
    console.log("myTimeout==>", this.myTimeout);
    if (this.myTimeout)
      this.myTimeout.unsubscribe();
  }
}
