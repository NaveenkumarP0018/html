import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { PerfectScrollbarModule, PERFECT_SCROLLBAR_CONFIG, PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { TruncateModule } from 'ng2-truncate';
import { FileUploadModule } from 'ng2-file-upload';
import { FileHelpersModule } from 'ngx-file-helpers';

import {NgxMaterialTimepickerModule} from 'ngx-material-timepicker';
import { MaindashboardComponent } from './manage/maindashboard.component';
import { MainDashboardRoutes } from './maindashboard.router';
import { MaterialModule } from '../../_shared/material.module';
import { TranslateModule } from '@ngx-translate/core';
import { ChartsModule } from 'ng2-charts/ng2-charts';
import { TotaldaywiseComponent } from './totaldaywise/totaldaywise.component';
import { ModulewiseChartComponent } from './modulewise-chart/modulewise-chart.component';
import { InterfaceChartsComponent } from './interface-charts/interface-charts.component';
import { SmsCampaignChartComponent } from './sms-campaign-chart/sms-campaign-chart.component';
import { ServiceChartComponent } from './service-chart/service-chart.component';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { TotalactivityComponent } from './totalactivity/totalactivity.component';
import { CountrywiseComponent } from './countrywise/countrywise.component';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  wheelPropagation: true
};

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    ReactiveFormsModule,
    PerfectScrollbarModule,
    FormsModule,
    FileHelpersModule,
    FileUploadModule,
    TruncateModule,
    MaterialModule,
    RouterModule.forChild(MainDashboardRoutes),
    NgxMaterialTimepickerModule,
   TranslateModule,
   ChartsModule,
   NgxMatSelectSearchModule
  ],

  declarations: [
    MaindashboardComponent,
    TotaldaywiseComponent,
    ModulewiseChartComponent,
    InterfaceChartsComponent,
    SmsCampaignChartComponent,
    ServiceChartComponent,
    TotalactivityComponent,
    CountrywiseComponent
  ],

  entryComponents: [],
  providers: [
    DatePipe,
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    },
   ]
})

export class MainDashboardModule { }
