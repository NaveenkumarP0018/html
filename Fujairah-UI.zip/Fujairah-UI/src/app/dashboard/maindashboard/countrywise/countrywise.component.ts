import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ICampSubmit } from '../_model/maindashboard.model';

@Component({
  selector: 'app-countrywise',
  templateUrl: './countrywise.component.html',
  styleUrls: ['./countrywise.component.scss']
})
export class CountrywiseComponent implements OnInit {
  @Input() requestData: ICampSubmit;
  @Output() CountryWiseData = new EventEmitter<number[]>(); 
  pieChartLabels1: string[] = ['UAE', 'USA', 'Oman', 'Kuwait', 'Qatar', 'UK'];
  pieChartData1: number[] = [5, 30, 30, 15, 10, 10];
  doughnutChartColors: any[] = [{
    backgroundColor: ['#4F81BD', '#C0504D', '#9BBB59', '#8064A2', '#FFA500', '#0000FF', '#FFFF33']
  }];
  globalChartOptions: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom',
      labels: {
        usePointStyle: true,
      }
    },
    labels:
    {
      render: 'text'
    }
  };
  constructor() { }

  ngOnInit() {
  }

}
