import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmsCampaignChartComponent } from './sms-campaign-chart.component';

describe('SmsCampaignChartComponent', () => {
  let component: SmsCampaignChartComponent;
  let fixture: ComponentFixture<SmsCampaignChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmsCampaignChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmsCampaignChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
