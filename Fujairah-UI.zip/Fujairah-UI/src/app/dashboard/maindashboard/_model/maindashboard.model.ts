
  export interface ICreditType {
    creditCode: string;
    creditName: string;
    creditTypeId: number;
  }

  export interface IUser {
    apiKey?: string;
    checker?: number;
    depts?: Dept[];
    emailId?: string;
    creditType?: ICreditType;
    firstname: string;
    hashedPassword?: string;
    isactive: number;
    lastname: string;
    login: string;
    mobileNo?: string;
    modules?: Module[];
    roles: Role[];
    userId: number;
    userType?: number;
  }

  
  export interface Role {
    roleCode: string;
    roleId: number;
    roleName: string; 
  
  }

  export interface Module {
    link?: string;
    menuId?: number;
    moduleId: number;
    modulename?: string;
    viewChecker?: number;
  }
  
  export interface Dept {
    deptId: number;
    deptName: string;
  }
  export interface IDepartment {
    creditType: ICreditType;
    deptId: number;
    deptName: string;
    description: string;
    status: number;
    users: IUser[];
  }
  

  export interface IDaywiseData {
    date: string;
    totalCount: number;
  }
  export interface ICampSubmit {
    deptId: number;
    from: string;
    roleId: number;
    to: string;
    users: number[];
  }
  
  export interface ICampData {
    baseUploaded: number;
    campId: number;
    campName: string;
    date: string;
    delivered: number;
    failed: number;
    sent: number;
  }
  
  export interface Idate {
    date: string;
    dateTime: string;
    hours: string;
    minutes: string;
    seconds: string;
    time: string;
  }
  
  export interface IModuleData {
    count: number;
    moduleName: string;
  }
  
  export interface IInterfaceData {
    baseUploaded: number;
    date: string;
    delivered: number;
    deptId: number;
    interfaceCode: string,
    failed: number;
    sent: number;
    userId: number;
  }
  export interface IServiceData {
    baseUploaded: number;
    date: string;
    delivered: number;
    deptId: number;
    failed: number;
    rownumber: number;
    sent: number;
    serviceCode: string;
    userId: number;
  }
  export interface ITotalCount {
    sms: number;
  }

  export enum PeriodicType {
    Today = '0',
    ThreeDays = '1',
    Week = "2",
    Month = "3",  
  }
  
  export enum usageWise{
    appUsage='0',
    userUsage='1'
  }
  export interface multiBarData {
    name: string;
    series: PieData[]
  }
  export interface PieData {
    name: string;
    value: number
  }
  export interface BarChart{
    label:string;
    data:any[]
  }
  export interface PieChart{
    data:any[];
    
  }
  export interface IWidget {
    isactive: boolean;
    status: number;
    widgetCode: string;
    widgetDesc: string;
    widgetId: number;
  }
  export enum widget{
    TotalDayWise='TD',
    TotalActivity='TA',
    ModuleWise='MW',
    SMSCampaign='SC',
    InterfaceWise='IW',
    PriorityWise='PW'
  }
  