export interface User {
    firstname: string;
    lastname: string;
    login: string;
    userId: number;
}

export interface IDepartment {
    creditType: ICreditTypes;
    deptId?: number;
    deptName: string;
    description: string;
    status?: number;
    users?: User[];
}
export interface ICreditTypes {
    creditCode?: string;
    creditName?: string;
    creditTypeId: number;
}
export interface CreditType {
    creditCode: string;
    creditName: string;
    creditTypeId: number;
    status: number;
}

export interface Dept {
    deptId: number;
    deptName: string;
    status: number;
}

export interface IModule {
    link: string;
    moduleId: number;
    modulename: string;
    viewChecker: number;
}

export interface IRole {
    roleCode: string;
    roleId: number;
    roleName: string;
}

export interface IUserCredit {
    availableCredit: number;
    creditTypeId: number;
    deptId: number;
    thresoldLimit: number;
    userCreditId: number;
}

export interface IUser {
    apiKey?: string;
    changePassword?: number;
    checker?: number;
    creditType?: CreditType;
    depts?: Dept[];
    emailId?: string;
    firstname: string;
    hashedPassword?: string;
    isactive?: number;
    language?: string;
    lastname: string;
    licensedTo?: string;
    login: string;
    mobileNo?: string;
    modules?: IModule[];
    roles?: IRole[];
    userCredit?: IUserCredit;
    userId: number;

}

