import { Component, OnInit, ViewChild, ElementRef, OnDestroy, AfterViewInit } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { ITokenInfo, AppConfig, IUserUpdateDto, userType } from '../../../_helpers/app.config';
import { MainDashBoardService } from '../_service/maindashboard.service';
import { AlertMessageService, ActionType } from '../../../_services/AlertMessageService';
import { DatePipe } from '@angular/common';
import { TranslateService } from '@ngx-translate/core';
import { Router } from '@angular/router';
import { Idate, usageWise, PeriodicType, ICampSubmit, BarChart, IUser, IDepartment, IWidget, widget } from '../_model/maindashboard.model';
import { Observable, Subject, ReplaySubject } from 'rxjs';
import { takeUntil, take } from 'rxjs/operators';
import { MatSelect } from '@angular/material';
import html2canvas from 'html2canvas';
//import 'chartjs-plugin-labels';
declare var $: any;

@Component({
  selector: 'app-maindashboard',
  templateUrl: './maindashboard.component.html',
  styleUrls: ['./maindashboard.component.scss']
})
export class MaindashboardComponent implements OnInit, OnDestroy, AfterViewInit {
widgetTD:boolean=false;
widgetTA:boolean=false;
widgetSC:boolean=false;
widgetIW:boolean=false;
widgetPW:boolean=false;
widgetMW:boolean=false;
expandIW:boolean=false;
expandPW:boolean=false;
expandCW:boolean=false;
expandTDW:boolean=false;
expandTA:boolean=false;
expandMW:boolean=false;
  dashBoardForm: FormGroup;
  _roleCode: string = '';
  loginInfo: IUserUpdateDto;
  currentDateDate: Idate;
  loading: boolean = true;
  usersList: IUser[] = [];
  dashboardLabel: string = '';
  fromDate: Date;
  toDate: Date;
  campsubmitData: ICampSubmit;
  departmentId: number = 0;
  totaldaydata: BarChart[] = [];
  totalActivitydata: number[] = [];
  Countrydata: number[] = [];
  moduledata: number[] = [];
  campaigndata: BarChart[] = [];
  modata: number[] = [];
  interfacedata: BarChart[] = [];
  prioritydata: BarChart[] = [];
  private _onDestroy = new Subject<void>();
  public filteredUsers: ReplaySubject<IUser[]> = new ReplaySubject<IUser[]>(1);
  WidgetCount:number=0;
  @ViewChild('singleSelect') singleSelect: MatSelect;
  userId: number;
  expand1:boolean=false;
  constructor(private fb: FormBuilder, private dashBoardService: MainDashBoardService, private appConfig: AppConfig, private datePipe: DatePipe, private router: Router, private translate: TranslateService, private alertMessage: AlertMessageService) {
    let tokenInfo = this.appConfig.getTokenInfo() as ITokenInfo;
    if (tokenInfo) {
      this.loginInfo = (tokenInfo.tokenInfo as any).sub ? JSON.parse((tokenInfo.tokenInfo as any).sub) as IUserUpdateDto : undefined;
      console.log("loginInfo=>", this.loginInfo);
      this._roleCode = this.loginInfo.roles[0].roleCode;

    }
    else {
      this.router.navigate(['401']);
    }
  }
  ngOnInit() {
    this.dashBoardForm = this.fb.group({
      usageWise: ['0', Validators.required],
      periodicWise: ['0', Validators.required],
      users: [null],
      userFilterCtrl: [null]
    });
    this.dashBoardForm.get('userFilterCtrl').valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterUsers();
      });
    if (this._roleCode == 'NA') {
      this.dashboardLabel = this.translate.instant('DashBoardModule.manage.dashboardDataof') + this.loginInfo.login;
    }
    this.dashBoardService.getCurrentDate().subscribe((result: Idate) => {
      if (result) {
        this.currentDateDate = result;
        if (this._roleCode == "SA" || this._roleCode == "PA") {
          this.getAllUser();
        }
        else if (this._roleCode == "DA"){
          this.getDepartmentswithusers();
        }
        else
        {
          this.chartsLoading();
        }
        this.appUsageWiseChange();
        this.selectTab(this.dashBoardForm.value.periodicWise);
        console.log("currentDateDate==>", this.currentDateDate.date, new Date(this.currentDateDate.date));
      }
    });
  }

  getAllUser() {
    this.dashBoardService.getAllUsers().subscribe((response: IUser[]) => {
      console.log("Response user==>", response);
      if (response) {
        console.log("Response==>", response);
        this.usersList = response;
        console.log("filteredUsers==>", this.filteredUsers);

      } else {
        this.usersList = [];

      }
      this.filteredUsers.next(this.usersList.slice());
      this.chartsLoading();
    }, error => {
      this.usersList = [];
      this.filteredUsers.next(this.usersList.slice());
      let message = error.error.messages as string
      let errorMessage = error.status == 404 ? this.translate.instant('ActionNames.errorResponse') : message ? message : error.message;
      console.error("E-getAllUsers==>", JSON.stringify(error));
      this.showAlert(errorMessage, ActionType.ERROR, error.status);
   
      this.chartsLoading();
    });
  }

  getDepartmentswithusers() {
    this.dashBoardService.getAllDepartments().subscribe((response: IDepartment[]) => {
      if (response) {
        let index = response.findIndex(x => x.deptId == (this.loginInfo.depts.length > 0 ? this.loginInfo.depts[0].deptId : 0));
        if (index != -1) {
          this.usersList = response[index].users;
        }
      }
      else {
        this.usersList = [];
      }
      this.filteredUsers.next(this.usersList.slice());
      this.chartsLoading();
    }, error => {
      let message = error.error.messages as string;
      this.usersList = [];
      this.filteredUsers.next(this.usersList.slice());
      let errorMessage = error.status == 404 ? this.translate.instant('ActionNames.errorResponse') : message ? message : error.message;
      console.error("E-getAllDepartments==>", JSON.stringify(error));
      this.showAlert(errorMessage, ActionType.ERROR, error.status);
      this.chartsLoading();
    });
  }

  appUsageWiseChange() {
    if (this.dashBoardForm.value.usageWise == usageWise.appUsage) {
      this.dashBoardForm.get('users').setValue(null);
      this.dashBoardForm.get('users').clearValidators();
      this.dashBoardForm.get('users').updateValueAndValidity();
      this.userId = this._roleCode == userType.NormalUser ? this.loginInfo.userId : 0;
      this.departmentId = this.loginInfo.depts.length > 0 ? this.loginInfo.depts[0].deptId : 0
      let from = this.datePipe.transform(this.fromDate, "yyyy-MM-dd");
      let to = this.datePipe.transform(this.toDate, "yyyy-MM-dd")
      from = from + " 00:00:00";
      to = to + " 23:59:59"
      this.campsubmitData = {
        deptId: this.departmentId,
        from: from,
        roleId: this.loginInfo.roles.length > 0 ? this.loginInfo.roles[0].roleId : 0,
        to: to,
        users: this.userId == 0 ? [] : [this.userId]
      } as ICampSubmit;
      console.log("campsubmitData=>", this.campsubmitData);

      if (this.dashBoardForm.value.usageWise == usageWise.appUsage) {
        if (this._roleCode == 'SA' || this._roleCode == 'PA') {
          this.dashboardLabel = this.translate.instant('DashBoardModule.manage.appusageLabel');
        }
        else if (this._roleCode == 'DA') {
          this.dashboardLabel = this.translate.instant('DashBoardModule.manage.deptUsageLabel');
        }
      }
    }
    else {
      // this.filteredUsers.next(this.usersList.slice());
      this.dashBoardForm.get('users').setValidators([Validators.required]);
      this.dashBoardForm.get('users').updateValueAndValidity();
    }
  }

  selectTab(selectvalue: string) {
    console.log("tab selectvalue==>", selectvalue);
    let currentDateFrom: Date;
    if (this.currentDateDate)
      currentDateFrom = new Date(this.currentDateDate.date);
    else {
      currentDateFrom = new Date();
    }
    switch (selectvalue) {
      case PeriodicType.Month:
        this.toDate = new Date(currentDateFrom.setDate(currentDateFrom.getDate()));
        this.fromDate = new Date(currentDateFrom.setDate(currentDateFrom.getDate() - 29));
        break;
      case PeriodicType.Week:
        this.toDate = new Date(currentDateFrom.setDate(currentDateFrom.getDate()));
        this.fromDate = new Date(currentDateFrom.setDate(currentDateFrom.getDate() - 6));
        break;
      case PeriodicType.ThreeDays:
        this.toDate = new Date(currentDateFrom.setDate(currentDateFrom.getDate()));
        this.fromDate = new Date(currentDateFrom.setDate(currentDateFrom.getDate() - 2));
        break;
      default:
        this.toDate = new Date(currentDateFrom);
        this.fromDate = new Date(currentDateFrom);
        break;
    }
    let from = this.datePipe.transform(this.fromDate, "yyyy-MM-dd");
    let to = this.datePipe.transform(this.toDate, "yyyy-MM-dd")
    from = from + " 00:00:00";
    to = to + " 23:59:59"
    this.campsubmitData = {
      deptId: this.departmentId,
      from: from,
      roleId: this.loginInfo.roles.length > 0 ? this.loginInfo.roles[0].roleId : 0,
      to: to,
      users: this.userId == 0 ? [] : [this.userId]
    } as ICampSubmit;
    console.log("campsubmitData=>", this.campsubmitData);
    if (this.dashBoardForm.value.usageWise == usageWise.appUsage) {
      if (this._roleCode == 'SA' || this._roleCode == 'PA') {
        this.dashboardLabel = this.translate.instant('DashBoardModule.manage.appusageLabel');
      }
      else if (this._roleCode == 'DA') {
        this.dashboardLabel = this.translate.instant('DashBoardModule.manage.deptUsageLabel');
      }
    }
    else {
      if (this._roleCode == 'DA' && this.dashBoardForm.value.users) {
        this.dashboardLabel = this.translate.instant('DashBoardModule.manage.dashboardDataof') + this.dashBoardForm.value.users.login;
      }
    }
  }

  userSelection() {
    let selecteduser = this.dashBoardForm.value.users
    let index = this.usersList.findIndex(user => user.login == selecteduser.login);
    if (index != -1) {
      this.userId = this.usersList[index].userId;
    }
    console.log("userId==>", this.userId)
    let from = this.datePipe.transform(this.fromDate, "yyyy-MM-dd");
    let to = this.datePipe.transform(this.toDate, "yyyy-MM-dd")
    from = from + " 00:00:00";
    to = to + " 23:59:59"
    this.campsubmitData = {
      deptId: this.departmentId,
      from: from,
      roleId: this.loginInfo.roles.length > 0 ? this.loginInfo.roles[0].roleId : 0,
      to: to,
      users: this.userId == 0 ? [] : [this.userId]
    } as ICampSubmit;
    console.log("campsubmitData=>", this.campsubmitData);
    if (this.dashBoardForm.value.users != null) {
      this.dashboardLabel = this.translate.instant('DashBoardModule.manage.dashboardDataof') + this.dashBoardForm.value.users.login;
    }
  }

  chartsLoading() {
    
    this.dashBoardService.getAllWidgetsByUserId(this.loginInfo.userId).subscribe((response: IWidget[]) => {
      console.log("Response getAllWidgetsByUserId==>", response);
      if (response) {
        console.log("Response==>", response);
        response.forEach(chart => {
          console.log('chart', chart)
          Object.values(widget).forEach(code=>{
            if(code==chart.widgetCode && chart.isactive==true){
              this['widget'+chart.widgetCode]=true;
              this.WidgetCount++;
            }
          });
        });
      } 
      else {
      }
      this.loading = false;
    }, error => {
      let message = error.error.messages as string
      let errorMessage = error.status == 404 ? this.translate.instant('ActionNames.errorResponse') : message ? message : error.message;
      console.error("E-getAllWidgetsByUserId==>", JSON.stringify(error));
      this.showAlert(errorMessage, ActionType.ERROR, error.status);
      this.loading = false;
    });
  }
  private setInitialValue() {
    this.filteredUsers
      .pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(() => {
        this.singleSelect.compareWith = (a: IUser, b: IUser) => a.login === b.login;
      });
  }

  private filterUsers() {
    if (!this.usersList) {
      return;
    }
    let search = this.dashBoardForm.get('userFilterCtrl').value;
    if (!search) {
      this.filteredUsers.next(this.usersList.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    this.filteredUsers.next(
      this.usersList.filter(bank => bank.login.toLowerCase().indexOf(search) > -1)
    );
  }
  receivetotalData(event) {
    console.log("receivetotalData event==>", event);
    this.totaldaydata = event;
  }
  receivedInterfaceData(event) {
    console.log("receivedInterfaceData event==>", event);
    this.interfacedata = event;
  }
  receivemoduleData(event) {
    console.log("receivemoduleData event==>", event);
    this.moduledata = event;
  }
  receivedprioritywiseDataData(event) {
    console.log("receivedprioritywiseDataData event==>", event);
    this.prioritydata = event;
  }
  receivedcampaignData(event) {
    console.log("receivedprioritywiseDataData event==>", event);
    this.campaigndata = event;
  }
  receivedMoData(event) {
    console.log("receivedMoData event==>", event);
    this.modata = event;
  }
  receivedCountryData(event) {
    console.log("receivedCountryData event==>", event);
    this.Countrydata = event;
  }
  receivedTotalActivityData(event) {
    console.log("receivedCountryData event==>", event);
    this.totalActivitydata = event;
  }
  navigatetoProfile(){
    this.loading=true;
    this.router.navigate(['/profile'])
  }
  ngAfterViewInit() {
    if (this.singleSelect)
      this.setInitialValue();
  }

  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }
  showAlert(error: any, action: ActionType, status: number = 0) {
    if (status == 401)
      this.router.navigate(['401']);
    else setTimeout(() => this.alertMessage.showAlert(error, action));
  }
  downloadImage(type:string,imageType:string){
    console.log("download image==>",type);
    let obj:any;
    let chartName:string='';
    if(type=='1'){
      obj = document.getElementById("totaldaywise");
      chartName="Total_Day_Wise-Chart";
    }
    else if(type=='2'){
      obj = document.getElementById("totalactivity");
      chartName="Total_Activity_Chart"
    }
    else if(type=='3'){
      obj = document.getElementById("countrywise");
      chartName="Country_Wise_Chart"
    }
    else if(type=='4'){
      obj = document.getElementById("modulewise");
      chartName="Module_Wise_Chart"
    }
    else if(type=='5'){
      obj = document.getElementById("smscampaigns");
      chartName="SMS_Campaign_Chart"
    }
    else if(type=='6'){
      // obj = document.getElementById("countrywise");
      // chartName="Interface_Wise_Chart"
    }
    else if(type=='7'){
      obj = document.getElementById("interfacewise");
      chartName="Interface_Wise_Chart"
    }
    else if(type=='8'){
      obj = document.getElementById("prioritywise");
      chartName="Priority_Wise_Chart";
    }
    console.log("obj==>",obj)
    html2canvas(obj).then(canvas => {
      var a = document.createElement("a");
      a.href = canvas.toDataURL("image/"+imageType);
      a.download = chartName + '.' + imageType;
      a.click();           
      if (navigator.msSaveBlob) { // IE10+
        var blob = canvas.msToBlob();
        return navigator.msSaveBlob(blob, chartName + '.' + imageType);
      }       
    });
  }
  expand(event) {
    //this.expand1 = !this.expand1;
    var idAttr = event.srcElement.id;
    $("." + idAttr).toggleClass('expand');
  }

}
