import { ConsumerService } from '../../../_helpers/ConsumerService';
import { Injectable } from '@angular/core';
import { LoadApiUrls } from '../../../_helpers/api.urls';
import { Observable } from 'rxjs';
import {  ICampSubmit, ICampData, IDaywiseData, IInterfaceData, IModuleData, IServiceData, Idate, IUser, IDepartment, ITotalCount, IWidget } from '../_model/maindashboard.model';



@Injectable({ providedIn: 'root' })

export class MainDashBoardService {
    component = "DashBoard";
    constructor(private apiUrls: LoadApiUrls, private consumer: ConsumerService) {
    }

    getAllUsers(): Observable<IUser[]> {
        let _apiurlsdetials = this.apiUrls.getApiServiceUrlByComponentAndMethod('Users', "getAllUsers")
        console.log("URL Get from config : =====>  ", _apiurlsdetials);
        if (_apiurlsdetials) {
            console.log("URL Get from config : ---->  ", _apiurlsdetials);
            return this.consumer.serviceConsumer<IUser[]>(_apiurlsdetials.url, _apiurlsdetials.type, null, 'users');
        } else {
            console.log("URL Get from config : ---->  ", "Url not found..");
            return Observable.throw({ error: { messages: "url not found" } });
        }
     
    }

    getAllDepartments(): Observable<IDepartment[]>{
        let _apiurlsdetials = this.apiUrls.getApiServiceUrlByComponentAndMethod(this.component, "getAllDepartments")
        console.log("URL Get from config : =====>  ", _apiurlsdetials);
        if (_apiurlsdetials) {
            console.log("URL Get from config : ---->  ", _apiurlsdetials);
            return this.consumer.serviceConsumer<IDepartment[]>(_apiurlsdetials.url, _apiurlsdetials.type, null, 'departments');
        } else {
            console.log("URL Get from config : ---->  ", "Url not found..");
            return Observable.throw({ error: { messages: "url not found" } });
        }
    }
    getAllWidgetsByUserId(userid: number): Observable<IWidget[]> {
        let _apiurlsdetials = this.apiUrls.getApiServiceUrlByComponentAndMethod(this.component, "getAllWidgetsByUserId")
        console.log("URL Get from config : =====>  ", _apiurlsdetials);
        if (_apiurlsdetials) {
          console.log("URL Get from config : ---->  ", _apiurlsdetials);
          let url = _apiurlsdetials.url.replace('{userid}', userid + '');
          return this.consumer.serviceConsumer<IWidget[]>(url, _apiurlsdetials.type, null, 'widgets');
        } else {
          console.log("URL Get from config : ---->  ", "Url not found..");
          return Observable.throw({ error: { messages: "url not found" } });
        }
      }
    getCurrentDate(): Observable<Idate> {
        let _apiurlsdetials = this.apiUrls.getApiServiceUrlByComponentAndMethod(this.component, "getCurrentDate")
        if (_apiurlsdetials) {
          console.log("URL Get from config : ---->  ", _apiurlsdetials.url);
          return this.consumer.serviceConsumer<Idate>(_apiurlsdetials.url, _apiurlsdetials.type, null, '');
        }
        else {
          console.log("URL Get from config : ---->  ", "Url not found..");
          return Observable.throw({ error: { messages: "url not found" } });
        }
      }
    getCampWiseCount(campsubmitData:ICampSubmit): Observable<ICampData[]> {
        let _apiurlsdetials = this.apiUrls.getApiServiceUrlByComponentAndMethod(this.component, "getCampWiseCount")
        console.log("URL Get from config : =====>  ", _apiurlsdetials);
        if (_apiurlsdetials) {
            console.log("URL Get from config : ---->  ", _apiurlsdetials);
            return this.consumer.serviceConsumer<ICampData[]>(_apiurlsdetials.url, _apiurlsdetials.type, campsubmitData, 'campData');
        } else {
            console.log("URL Get from config : ---->  ", "Url not found..");
            return Observable.throw({ error: { messages: "url not found" } });
        }
        
    }
    getDayWiseCount(campsubmitData:ICampSubmit): Observable<IDaywiseData[]> {
        let _apiurlsdetials = this.apiUrls.getApiServiceUrlByComponentAndMethod(this.component, "getDayWiseCount")
        console.log("URL Get from config : =====>  ", _apiurlsdetials);
        if (_apiurlsdetials) {
            console.log("URL Get from config : ---->  ", _apiurlsdetials);
            return this.consumer.serviceConsumer<IDaywiseData[]>(_apiurlsdetials.url, _apiurlsdetials.type, campsubmitData, 'daywiseData');
        } else {
            console.log("URL Get from config : ---->  ", "Url not found..");
            return Observable.throw({ error: { messages: "url not found" } });
        }
    }
    getModuleWiseCount(campsubmitData:ICampSubmit): Observable<IModuleData[]> {
        let _apiurlsdetials = this.apiUrls.getApiServiceUrlByComponentAndMethod(this.component, "getModuleWiseCount")
        console.log("URL Get from config : =====>  ", _apiurlsdetials);
        if (_apiurlsdetials) {
            console.log("URL Get from config : ---->  ", _apiurlsdetials);
            return this.consumer.serviceConsumer<IModuleData[]>(_apiurlsdetials.url, _apiurlsdetials.type, campsubmitData, 'moduleData');
        } else {
            console.log("URL Get from config : ---->  ", "Url not found..");
            return Observable.throw({ error: { messages: "url not found" } });
        }
    }
    getInterfaceWiseCount(campsubmitData:ICampSubmit): Observable<IInterfaceData[]> {
        let _apiurlsdetials = this.apiUrls.getApiServiceUrlByComponentAndMethod(this.component, "getInterfaceWiseCount")
        console.log("URL Get from config : =====>  ", _apiurlsdetials);
        if (_apiurlsdetials) {
            console.log("URL Get from config : ---->  ", _apiurlsdetials);
            return this.consumer.serviceConsumer<IInterfaceData[]>(_apiurlsdetials.url, _apiurlsdetials.type, campsubmitData, 'interfaceData');
        } else {
            console.log("URL Get from config : ---->  ", "Url not found..");
            return Observable.throw({ error: { messages: "url not found" } });
        }
    }
    getServicewiseCount(createServicecode: ICampSubmit): Observable<IServiceData[]> {
        let _apiurlsdetials = this.apiUrls.getApiServiceUrlByComponentAndMethod(this.component, "getServicewiseCount")
        console.log("URL Get from config : =====>  ", _apiurlsdetials);
        if (_apiurlsdetials) {
            console.log("URL Get from config : ---->  ", _apiurlsdetials);
            return this.consumer.serviceConsumer<IServiceData[]>(_apiurlsdetials.url, _apiurlsdetials.type, createServicecode, 'serviceData');
        } else {
            console.log("URL Get from config : ---->  ", "Url not found..");
            return Observable.throw({ error: { messages: "url not found" } });
        }
    }
    getTotalCount(createtotalActivity: ICampSubmit): Observable<ITotalCount[]> {
        let _apiurlsdetials = this.apiUrls.getApiServiceUrlByComponentAndMethod(this.component, "getTotalCount")
        console.log("URL Get from config : =====>  ", _apiurlsdetials);
        if (_apiurlsdetials) {
            console.log("URL Get from config : ---->  ", _apiurlsdetials);
            return this.consumer.serviceConsumer<ITotalCount[]>(_apiurlsdetials.url, _apiurlsdetials.type, createtotalActivity, 'totalCount');
        } else {
            console.log("URL Get from config : ---->  ", "Url not found..");
            return Observable.throw({ error: { messages: "url not found" } });
        }
    }
}
