import { Routes } from '@angular/router';
import { ApprovalspageComponent } from './manage/approvals.component';
// import { ApprovalspageComponent } from './manage/approvals.component';

export const ApprovalspageRoutes: Routes = [

  {
      path: '',
      component: ApprovalspageComponent
  }
]
