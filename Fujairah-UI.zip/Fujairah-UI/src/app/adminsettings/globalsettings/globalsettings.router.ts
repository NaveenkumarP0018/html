import { Routes } from '@angular/router';
import { GlobalsettingsComponent } from './manage/globalsettings.component';



export const globalsettingsrouts: Routes = [{
    
    path: '',
    component: GlobalsettingsComponent
}];
