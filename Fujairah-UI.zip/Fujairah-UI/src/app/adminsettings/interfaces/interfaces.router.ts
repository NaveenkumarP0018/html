import { Routes } from '@angular/router';
import { InterfacesComponent } from './manage/interfaces.component';
// import { InterfacesComponent } from './interfaces.component';

export const InterfacesRoutes: Routes = [

  {
      path: '',
      component: InterfacesComponent
  }
]