import { Routes } from '@angular/router';
import { ServicemanagementComponent } from './manage/servicemanagement.component';

export const ServiceManagementRouts = [{
    path: '',
    component: ServicemanagementComponent
}]
