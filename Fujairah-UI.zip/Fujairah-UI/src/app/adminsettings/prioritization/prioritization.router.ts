import { PrioritizationComponent } from './manage/prioritization.component';
import { Routes } from '@angular/router';

export const PrioritizationRoutes: Routes = [

  {
      path: '',
      component: PrioritizationComponent

  }
]
