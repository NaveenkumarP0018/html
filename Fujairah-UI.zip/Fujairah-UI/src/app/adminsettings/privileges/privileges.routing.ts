import { Routes } from '@angular/router';

import { PrivilegesComponent } from './managepriviliges/privileges.component';

export const PrivilegesRoutes: Routes = [{
  path: '',
  component: PrivilegesComponent
}];
