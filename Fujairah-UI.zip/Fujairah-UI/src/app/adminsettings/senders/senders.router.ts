import { Routes } from '@angular/router';
import { SendersComponent } from './manage/senders.component';

export const senderrouts: Routes = [

  {
      path: '',
      component: SendersComponent
  }
]