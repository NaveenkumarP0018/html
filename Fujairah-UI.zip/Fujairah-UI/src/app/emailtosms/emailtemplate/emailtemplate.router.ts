import { Routes } from '@angular/router';
import { EmailTemplateComponent } from './manage/emailtemplate.component';

export const EmailTemplateRoutes: Routes = [{
    path: '',
    component: EmailTemplateComponent
}];
